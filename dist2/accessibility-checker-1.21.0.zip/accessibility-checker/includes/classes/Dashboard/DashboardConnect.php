<?php
/* Rest class for the dashboard connect.
 *
 * @package Accessibility_Checker
 */

use \Firebase\JWT\JWT;

namespace EqualizeDigital\AccessibilityChecker\Rest\Dashboard;

class DashboardConnect {
	public function register_routes() {
		$this->api_version = '1';
		$this->namespace   = 'accessibility-checker/v' . $this->api_version;
		$this->rest_base   = 'dashboard';

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/connect',
			[
				'methods'  => \WP_REST_Server::CREATABLE,
				'callback' => [ $this, 'connect' ],
				'permission_callback' => '__return_true',
			]
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/disconnect',
			[
				'methods'  => \WP_REST_Server::CREATABLE,
				'callback' => [ $this, 'disconnect' ],
				'permission_callback' => '__return_true',
			]
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/status',
			[
				'methods'  => \WP_REST_Server::READABLE,
				'callback' => [ $this, 'status' ],
				'permission_callback' => '__return_true',
			]
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/token',
			[
				'methods'  => \WP_REST_Server::CREATABLE,
				'callback' => [ $this, 'token_generate' ],
				'permission_callback' => '__return_true',
			]
		);
	}

	public function token_generate( $request ) {
		// Generate me a JWT token.
		$token = $this->generate_token();
	}

	public function connect( $request ) {
		// Connect to the dashboard.
	}

	public function disconnect( $request ) {
		// Disconnect from the dashboard.
	}

	public function status( $request ) {
		// Get the status of the connection.
	}

	private function generate_token() {
		// Generate a JWT token.

	}
}


